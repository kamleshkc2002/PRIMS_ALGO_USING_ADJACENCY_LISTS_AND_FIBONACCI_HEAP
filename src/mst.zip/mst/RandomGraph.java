import java.util.Random;
import java.util.*;
public class RandomGraph {
	private int NumNode;
	private int NumEdge;
	
	public RandomGraph(int nodes, double dense)
	{
		NumNode = nodes;
		NumEdge = (int) ( dense * nodes*(nodes-1)/2);
	}
	
	public SimpleGraph Generate(){
		SimpleGraph graph = new SimpleGraph();
		Random rd = new Random(System.currentTimeMillis());
		
		int weight;
		int IndexNodeA;
		int IndexNodeB;
		// add node to graph
		for(int i = 0; i < NumNode; i++)
		{
			Node node = new Node(i);
			graph.AddNode(node);
		}
		
		int edgecount = 0;
		ArrayList<Node> graphNode = graph.getNodes();
		while(edgecount < NumEdge )
		{
			weight = rd.nextInt(1000) + 1;
			IndexNodeA = rd.nextInt(NumNode);
			IndexNodeB = rd.nextInt(NumNode);
			/*while(IndexNodeB == IndexNodeA)
			{
				IndexNodeA = (int )(rd.nextInt(NumNode) );
			}*/
			Edge e = new Edge(graphNode.get(IndexNodeA), 
								graphNode.get(IndexNodeB), (double)weight);
			boolean IsAdded = graph.AddEdge(e);
			if(IsAdded)
				edgecount++;
			System.out.println("Edge No."+edgecount);

		}
		
		System.out.println("A new random graph");
		return graph;
		
		
	}
	
}
