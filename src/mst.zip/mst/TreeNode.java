
public class TreeNode {
	private int degree;
	private Node n;
	
}
