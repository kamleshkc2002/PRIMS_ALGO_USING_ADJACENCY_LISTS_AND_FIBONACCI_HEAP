import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class mst {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		long ArrayStartTime;
		long HeapStartTime;
		long ArrayEndTime;
		long HeapEndTime;
		int numEdges;
		int numNodes;
		ArrayList<Edge> resultMST;
		//ArrayList<Edge> resultMST2;
		//random mode: mst -r n d  n vertices with d% density
		RandomGraph rdgraph = new RandomGraph(1000, 1);
		SimpleGraph randomGraph = rdgraph.Generate();
		//user input mode: mst -s filename
		//user input mode: mst -f filename
		SimpleGraph InputGraph = new SimpleGraph();
		try {
			Scanner FileIn = new Scanner(new File("graph.txt"));
			numNodes = Integer.parseInt(FileIn.next() );
			numEdges = Integer.parseInt(FileIn.next() );
			while(FileIn.hasNextLine())
			{
				Node a = new Node(Integer.parseInt(FileIn.next()) );
				Node b = new Node(Integer.parseInt(FileIn.next()) );
				Edge e = new Edge(a, b, Integer.parseInt(FileIn.next()) );
				InputGraph.AddNode(a);
				InputGraph.AddNode(b);
				InputGraph.AddEdge(e);
			}
			
			FileIn.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		
		//fibMST
		/*// to init the neighbour edge of each node.
		MSTFib mstfib = new MSTFib(InputGraph);
		printMST(mstfib.getMST());
		System.out.println("MST cost "+mstfib.getTotalCost());
		
		
		//simple MST input mode
		MSTSimple simpleMST = new MSTSimple(InputGraph);
		printMST(simpleMST.getMST());
		System.out.println("MSTSimple cost "+simpleMST.getTotalCost());*/
		
		//fibMST random mode
		HeapStartTime = System.currentTimeMillis();
		MSTFib mstfib = new MSTFib(randomGraph);
		printMST(mstfib.getMST());
		System.out.println("MST cost "+mstfib.getTotalCost());
		HeapEndTime = System.currentTimeMillis() - HeapStartTime;
		//simple MST random mode
		ArrayStartTime = System.currentTimeMillis();
		MSTSimple simpleMST = new MSTSimple(randomGraph);
		printMST(simpleMST.getMST());
		System.out.println("MSTSimple cost "+simpleMST.getTotalCost());
		ArrayEndTime = System.currentTimeMillis() - ArrayStartTime;
		System.out.println("Heap time "+ HeapEndTime + "; Array time "+ ArrayEndTime);

	}
	
	public static void printMST(ArrayList<Edge> mst)
	{
		if(mst != null)
		{
			for(Edge e : mst)
	    	{
	    		System.out.print("Edge: "+ e.getNodeA().getNodeID() +"-"
	    				+e.getNodeB().getNodeID()+" Weight: "+e.getWeight() +", ");
	    	}
		}
		else 
			System.out.println("No MST exist. Can't print mst");
		
	}

}
